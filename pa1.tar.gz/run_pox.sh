#!/bin/bash
./pox/pox.py cs144.ofhandler cs144.srhandler
